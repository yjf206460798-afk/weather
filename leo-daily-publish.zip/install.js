const toast = document.getElementById("toast");
const copyLinkButton = document.getElementById("copyLinkButton");
const promptInstallButton = document.getElementById("promptInstallButton");
const browserNotice = document.getElementById("browserNotice");
const androidSteps = document.getElementById("androidSteps");
const iosSteps = document.getElementById("iosSteps");
const desktopSteps = document.getElementById("desktopSteps");

let deferredInstallPrompt = null;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("is-visible");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => {
    toast.classList.remove("is-visible");
  }, 2400);
}

function detectDevice() {
  const ua = navigator.userAgent || "";
  const isInlineBrowser = /MicroMessenger|QQ\/|Weibo|DingTalk|Lark|Feishu/i.test(ua);
  const isIOS = /iPhone|iPad|iPod/i.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  const isAndroid = /Android/i.test(ua);
  const isMobile = isIOS || isAndroid;

  browserNotice.hidden = !isInlineBrowser;
  iosSteps.hidden = !isIOS;
  androidSteps.hidden = !isAndroid;
  desktopSteps.hidden = isMobile;

  if (!isMobile) {
    desktopSteps.hidden = false;
  }
}

async function copyInstallLink() {
  const link = new URL("./install.html", window.location.href).href;
  try {
    await navigator.clipboard.writeText(link);
    showToast("链接已复制");
  } catch {
    showToast("复制失败，可以直接复制浏览器地址栏");
  }
}

function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) return;
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => {
      // The install guide still works without offline caching.
    });
  });
}

window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault();
  deferredInstallPrompt = event;
  promptInstallButton.hidden = false;
});

promptInstallButton.addEventListener("click", async () => {
  if (!deferredInstallPrompt) return;
  deferredInstallPrompt.prompt();
  await deferredInstallPrompt.userChoice;
  deferredInstallPrompt = null;
  promptInstallButton.hidden = true;
});

copyLinkButton.addEventListener("click", copyInstallLink);
window.addEventListener("load", () => window.lucide?.createIcons());
detectDevice();
registerServiceWorker();
