const storeKey = "leo-daily-settings-v1";

const state = {
  weather: null,
  location: null,
  outfitOffset: 0,
  mealOffset: 0,
  deferredInstallPrompt: null,
  settings: {
    periodStart: 3,
    periodEnd: 10,
    mealSlot: "auto",
    cycleTracker: {
      lastStart: "",
      lastEnd: "",
      cycleLength: 28,
      periodLength: 8
    }
  }
};

const elements = {};

const weatherCodes = {
  0: "晴朗",
  1: "大体晴",
  2: "有些云",
  3: "阴天",
  45: "有雾",
  48: "雾凇",
  51: "小毛毛雨",
  53: "毛毛雨",
  55: "较强毛毛雨",
  56: "冻毛毛雨",
  57: "强冻毛毛雨",
  61: "小雨",
  63: "中雨",
  65: "大雨",
  66: "冻雨",
  67: "强冻雨",
  71: "小雪",
  73: "中雪",
  75: "大雪",
  77: "雪粒",
  80: "阵雨",
  81: "较强阵雨",
  82: "强阵雨",
  85: "阵雪",
  86: "强阵雪",
  95: "雷阵雨",
  96: "雷阵雨伴冰雹",
  99: "强雷阵雨伴冰雹"
};

const mercuryCycles2026 = [
  {
    label: "双鱼座水逆",
    shadowStart: "2026-02-11",
    start: "2026-02-26",
    end: "2026-03-20",
    shadowEnd: "2026-04-09"
  },
  {
    label: "巨蟹座水逆",
    shadowStart: "2026-06-13",
    start: "2026-06-29",
    end: "2026-07-23",
    shadowEnd: "2026-08-07"
  },
  {
    label: "天蝎座水逆",
    shadowStart: "2026-10-04",
    start: "2026-10-24",
    end: "2026-11-13",
    shadowEnd: "2026-11-30"
  }
];

const luckyItems = [
  "金色发夹",
  "向日葵挂件",
  "珊瑚色唇膏",
  "小镜子",
  "暖调香水",
  "亮色托特包",
  "亚麻丝巾",
  "琥珀耳饰",
  "手写便签",
  "橘色发圈",
  "细金戒指",
  "小幅画册"
];

const luckyColors = [
  "珊瑚橙",
  "向日葵黄",
  "鼠尾草绿",
  "清水蓝",
  "奶油白",
  "覆盆子红",
  "暖金色",
  "石榴粉"
];

const luckyNotes = [
  "把喜欢的东西摆在看得见的地方，状态会慢慢亮起来。",
  "今天适合相信自己的审美，选那个第一眼就心动的版本。",
  "表达不用很大声，认真挑选的小细节也会被看见。",
  "给自己留一点松弛时间，灵感会在不赶路的时候回来。",
  "适合穿一点有存在感的颜色，气场会自然跟上。",
  "先照顾舒服，再照顾漂亮；两件事今天可以同时做到。"
];

function $(selector) {
  return document.querySelector(selector);
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function formatDate(date) {
  return new Intl.DateTimeFormat("zh-CN", {
    month: "long",
    day: "numeric",
    weekday: "long"
  }).format(date);
}

function dateKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function hashString(value) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function seededRandom(seed) {
  let current = seed >>> 0;
  return () => {
    current += 0x6d2b79f5;
    let value = current;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

function stablePick(list, salt) {
  const random = seededRandom(hashString(`${dateKey()}-${salt}`));
  return list[Math.floor(random() * list.length)];
}

function stableShuffle(list, salt) {
  const random = seededRandom(hashString(`${dateKey()}-${salt}`));
  return [...list]
    .map((item) => ({ item, score: random() }))
    .sort((a, b) => a.score - b.score)
    .map((entry) => entry.item);
}

function rotateOptions(list, offset, count) {
  if (!list.length) return [];
  return Array.from({ length: Math.min(count, list.length) }, (_, index) => {
    return list[(offset + index) % list.length];
  });
}

function loadSettings() {
  try {
    const saved = JSON.parse(localStorage.getItem(storeKey) || "{}");
    const defaultTracker = state.settings.cycleTracker;
    state.settings = {
      ...state.settings,
      ...saved.settings,
      cycleTracker: {
        ...defaultTracker,
        ...(saved.settings?.cycleTracker || {})
      }
    };
    state.location = saved.location || null;
  } catch {
    state.location = null;
  }
}

function saveSettings() {
  localStorage.setItem(
    storeKey,
    JSON.stringify({
      settings: state.settings,
      location: state.location
    })
  );
}

function showToast(message) {
  elements.toast.textContent = message;
  elements.toast.classList.add("is-visible");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => {
    elements.toast.classList.remove("is-visible");
  }, 2600);
}

function setLoading(isLoading) {
  elements.useLocationButton.disabled = isLoading;
  elements.citySearchButton.disabled = isLoading;
  if (isLoading) {
    elements.weatherSummary.textContent = "正在看她那边的天气";
  }
}

function getPosition() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("当前浏览器不支持定位"));
      return;
    }

    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: true,
      timeout: 12000,
      maximumAge: 1000 * 60 * 20
    });
  });
}

async function reverseGeocode(latitude, longitude) {
  const fallbackName = `当前位置 ${Number(latitude).toFixed(2)}, ${Number(longitude).toFixed(2)}`;
  const url = new URL("https://api.bigdatacloud.net/data/reverse-geocode-client");
  url.search = new URLSearchParams({
    latitude,
    longitude,
    localityLanguage: "zh"
  });

  try {
    const response = await fetch(url);
    if (!response.ok) return fallbackName;
    const data = await response.json();
    const parts = [data.locality || data.city, data.principalSubdivision, data.countryName]
      .filter(Boolean)
      .filter((part, index, list) => list.indexOf(part) === index);
    return parts.slice(0, 2).join(" · ") || fallbackName;
  } catch {
    return fallbackName;
  }
}

async function searchCity(name) {
  const url = new URL("https://geocoding-api.open-meteo.com/v1/search");
  url.search = new URLSearchParams({
    name,
    count: "1",
    language: "zh",
    format: "json"
  });

  const response = await fetch(url);
  if (!response.ok) throw new Error("城市搜索失败");
  const data = await response.json();
  const result = data.results?.[0];
  if (!result) throw new Error("没找到这个城市");

  return {
    name: [result.name, result.admin1, result.country].filter(Boolean).slice(0, 2).join(" · "),
    latitude: result.latitude,
    longitude: result.longitude
  };
}

async function fetchWeather(location) {
  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.search = new URLSearchParams({
    latitude: String(location.latitude),
    longitude: String(location.longitude),
    timezone: "auto",
    forecast_days: "1",
    current:
      "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,rain,showers,snowfall,weather_code,wind_speed_10m",
    hourly: "temperature_2m,apparent_temperature,precipitation_probability,weather_code,uv_index",
    daily: "weather_code,temperature_2m_max,temperature_2m_min,uv_index_max,precipitation_probability_max,wind_speed_10m_max"
  });

  const response = await fetch(url);
  if (!response.ok) throw new Error("天气接口暂时不可用");
  return response.json();
}

function weatherDescription(code) {
  return weatherCodes[code] || "天气变化中";
}

function getWeatherContext(data) {
  if (!data?.current || !data?.daily) {
    return {
      temp: 26,
      feels: 27,
      min: 23,
      max: 29,
      uv: 5,
      rain: 20,
      wind: 10,
      code: 2,
      desc: "有些云"
    };
  }

  return {
    temp: Math.round(data.current.temperature_2m),
    feels: Math.round(data.current.apparent_temperature),
    min: Math.round(data.daily.temperature_2m_min?.[0] ?? data.current.temperature_2m),
    max: Math.round(data.daily.temperature_2m_max?.[0] ?? data.current.temperature_2m),
    uv: Number(data.daily.uv_index_max?.[0] ?? 0),
    rain: Number(data.daily.precipitation_probability_max?.[0] ?? 0),
    wind: Math.round(data.daily.wind_speed_10m_max?.[0] ?? data.current.wind_speed_10m ?? 0),
    code: data.current.weather_code,
    desc: weatherDescription(data.current.weather_code)
  };
}

function uvAdvice(context) {
  const uv = context.uv;
  const rainy = context.rain >= 55 || context.code >= 51;
  const windy = context.wind >= 24;

  if (uv >= 8) {
    return {
      badge: "SPF50+",
      label: "很强",
      text:
        "今天紫外线很强，出门建议 SPF50+、PA++++，脸颈耳后都照顾到；户外超过两小时补涂，太阳伞和帽子也值得带上。"
    };
  }

  if (uv >= 6) {
    return {
      badge: "SPF50",
      label: "偏强",
      text:
        "今天要认真涂防晒，建议 SPF50 或 SPF30+ 足量上脸；中午前后尽量加一层物理遮挡，通勤包里放一支小样方便补涂。"
    };
  }

  if (uv >= 3) {
    return {
      badge: rainy ? "SPF30" : "SPF30+",
      label: "中等",
      text:
        "今天紫外线中等，通勤和短时间外出建议 SPF30+；如果云多或下雨也别完全裸奔，薄涂会安心很多。"
    };
  }

  return {
    badge: windy ? "保湿优先" : "轻薄即可",
    label: "较弱",
    text:
      "今天紫外线较弱，长时间室内可以轻薄防晒或带防晒值的日霜；如果要在户外散步，还是给脸和脖子一点保护。"
  };
}

function comfortNote(context) {
  if (context.rain >= 60) return "带伞，鞋子别选怕湿的。";
  if (context.feels >= 32) return "体感偏热，优先透气和浅色。";
  if (context.feels <= 12) return "体感偏冷，外套要稳一点。";
  if (context.wind >= 28) return "风有点明显，发型和外套都要考虑。";
  return "整体舒适，今天可漂亮发挥。";
}

function renderWeather() {
  const context = getWeatherContext(state.weather);
  const advice = uvAdvice(context);
  const locationName = state.location?.name || "等待定位";

  elements.locationName.textContent = locationName;
  elements.currentTemp.textContent = state.weather ? String(context.temp) : "--";
  elements.weatherSummary.textContent = state.weather
    ? `${context.desc} · ${context.min}-${context.max}°C · 降雨 ${context.rain}%`
    : "点击当前位置或输入城市";
  elements.uvValue.textContent = state.weather ? context.uv.toFixed(1) : "--";
  elements.uvLabel.textContent = state.weather ? advice.label : "等待天气";
  elements.uvMeter.style.width = state.weather ? `${clamp((context.uv / 11) * 100, 4, 100)}%` : "0%";
  elements.feelsLike.textContent = state.weather ? `${context.feels}°` : "--";
  elements.comfortNote.textContent = state.weather ? comfortNote(context) : "先看看她那边的天";
  elements.spfBadge.textContent = state.weather ? advice.badge : "待判断";
  elements.sunscreenAdvice.textContent = state.weather
    ? advice.text
    : "拿到紫外线指数后，会给出 SPF、补涂和物理遮挡建议。";

  renderOutfits();
}

function buildOutfitOptions(context) {
  const rainy = context.rain >= 55 || context.code >= 51;
  const strongUv = context.uv >= 6;
  const windy = context.wind >= 24;
  const hot = context.feels >= 30;
  const warm = context.feels >= 24 && context.feels < 30;
  const mild = context.feels >= 17 && context.feels < 24;
  const cool = context.feels >= 10 && context.feels < 17;

  let base;
  if (hot) {
    base = [
      ["棉麻短袖 + 高腰阔腿裤", "清爽不贴身，适合热天通勤。", ["透气", "显精神"]],
      ["短袖针织 + A 字半裙", "柔软但有轮廓，拍照也很稳。", ["ISFP", "温柔"]],
      ["吊带裙 + 轻薄防晒衫", "室外防晒，室内也不臃肿。", ["防晒", "轻盈"]],
      ["宽松衬衫 + 百慕大短裤", "干净利落，走路不会闷。", ["清爽", "利落"]],
      ["方领上衣 + 直筒牛仔裤", "日常但有一点小气场。", ["狮子座", "日常"]],
      ["无袖背心 + 伞裙 + 凉鞋", "轻快又不随便，适合热天约会。", ["约会", "轻盈"]],
      ["防晒衬衫 + 运动短裙", "能走很多路，也能保持漂亮。", ["防晒", "活力"]],
      ["短款 T 恤 + 工装半裙", "休闲里有一点酷感，适合低负担出门。", ["休闲", "酷感"]],
      ["泡泡袖短上衣 + 亚麻短裤", "甜度够但不闷，颜色可以选亮一点。", ["甜美", "透气"]],
      ["薄款连体裤 + 编织包", "一件成套，利落又省心。", ["省心", "利落"]],
      ["吊带长裙 + 宽檐帽", "漂亮、松弛，户外拍照也很出片。", ["出片", "遮阳"]],
      ["短袖衬衫 + 白色半裙", "干净明亮，适合想看起来清爽的一天。", ["明亮", "清爽"]]
    ];
  } else if (warm) {
    base = [
      ["薄衬衫 + 直筒裤", "温度友好，适合从白天穿到晚上。", ["通勤", "耐看"]],
      ["短袖开衫 + 碎花半裙", "有一点艺术感，也不会过分用力。", ["柔和", "漂亮"]],
      ["针织背心 + 白 T + 牛仔裙", "层次轻，气质很干净。", ["层次", "明亮"]],
      ["连衣裙 + 细腰带", "省心的一套，出门速度快。", ["省心", "有型"]],
      ["泡泡袖上衣 + 烟管裤", "甜度和利落感刚好平衡。", ["灵动", "修饰"]],
      ["短袖西装 + 背心 + 半裙", "有精神但不正式，适合见人。", ["精致", "通勤"]],
      ["法式衬衫 + 牛仔阔腿裤", "松弛耐看，适合逛街和通勤。", ["法式", "松弛"]],
      ["针织 POLO + A 字短裙", "清爽活泼，有一点学院感。", ["学院", "活泼"]],
      ["薄罩衫 + 吊带 + 直筒裤", "室内空调也能应对，层次轻。", ["空调房", "层次"]],
      ["短款开衫 + 高腰伞裙", "显比例，温柔又不闷。", ["显高", "温柔"]],
      ["T 恤 + 背带裤", "舒服减龄，适合懒得认真搭但想可爱。", ["减龄", "舒服"]],
      ["印花衬衫 + 白色短裤", "有假日感，心情会更明亮。", ["假日", "明亮"]]
    ];
  } else if (mild) {
    base = [
      ["薄针织 + 半裙 + 乐福鞋", "舒服、有质感，适合慢慢逛。", ["舒适", "有质感"]],
      ["牛仔外套 + 连衣裙", "早晚有保护，中午脱掉也好看。", ["早晚温差", "轻松"]],
      ["长袖衬衫 + 马甲 + 直筒裤", "文艺感足，层次也稳。", ["文艺", "层次"]],
      ["卫衣 + 百褶裙", "活泼一点，很适合狮子座的亮感。", ["活泼", "减龄"]],
      ["小西装 + T 恤 + 半裙", "不正式但很有精神。", ["精神", "精致"]],
      ["针织开衫 + 吊带裙", "温柔、好穿，适合早晚有风。", ["温柔", "层次"]],
      ["棒球外套 + 直筒牛仔裤", "轻松有活力，适合走路多的一天。", ["运动", "轻松"]],
      ["衬衫裙 + 短靴", "一件成型，有一点艺术感。", ["文艺", "省心"]],
      ["条纹衫 + 卡其裤", "法式日常，干净耐看。", ["法式", "日常"]],
      ["薄风衣 + T 恤 + 半裙", "温差友好，走路很有气场。", ["风衣", "气场"]],
      ["牛仔衬衫 + 白色阔腿裤", "清爽又有轮廓，适合拍照。", ["清爽", "出片"]],
      ["短毛衣 + 高腰长裤", "比例好，温度也刚刚好。", ["显高", "舒适"]]
    ];
  } else if (cool) {
    base = [
      ["软糯毛衣 + 半身长裙", "暖而不笨重，整个人会很温柔。", ["保暖", "柔软"]],
      ["风衣 + 针织内搭 + 牛仔裤", "走路带风，温差也能扛。", ["风衣", "耐穿"]],
      ["短外套 + 高领打底 + 阔腿裤", "上短下长，显比例。", ["显高", "稳妥"]],
      ["开衫 + 衬衫裙", "日常、轻松，坐办公室也舒服。", ["日常", "松弛"]],
      ["卫衣 + 休闲裤 + 厚底鞋", "适合懒得费劲但想保持可爱。", ["轻便", "舒服"]],
      ["皮衣 + 连衣裙 + 短靴", "酷一点，但仍然有女性感。", ["酷感", "约会"]],
      ["羊毛马甲 + 衬衫 + 半裙", "文艺层次足，室内也舒服。", ["文艺", "层次"]],
      ["针织套装 + 小白鞋", "省心舒服，整套看起来很完整。", ["套装", "省心"]],
      ["牛角扣外套 + 格纹裙", "学院感明显，冷一点也可爱。", ["学院", "可爱"]],
      ["短风衣 + 高腰牛仔裤", "利落显精神，通勤很稳。", ["通勤", "利落"]],
      ["毛衣背心 + 高领打底 + 直筒裙", "暖和又有细节，不会臃肿。", ["保暖", "精致"]],
      ["绒面外套 + 阔腿裤", "柔软有质感，适合低调漂亮。", ["质感", "松弛"]]
    ];
  } else {
    base = [
      ["羽绒服 + 高领毛衣 + 直筒裤", "保暖优先，线条保持清楚。", ["保暖", "利落"]],
      ["羊毛大衣 + 针织裙", "温柔大方，适合冷天约会。", ["约会", "暖"]],
      ["厚开衫 + 衬衫 + 加绒裤", "层层叠穿，进室内也好调节。", ["叠穿", "实用"]],
      ["短棉服 + 半裙 + 长靴", "暖和又保留一点小漂亮。", ["小漂亮", "抗冷"]],
      ["摇粒绒外套 + 运动裤", "轻松一整天，适合低能量日。", ["轻松", "舒服"]],
      ["长款羽绒服 + 毛线帽 + 雪地靴", "冷天先把安全感穿满。", ["抗冷", "实用"]],
      ["羊羔毛外套 + 高腰牛仔裤", "暖和但有精神，适合日常出门。", ["暖", "日常"]],
      ["大衣 + 围巾 + 长靴", "保暖和气场都在线。", ["气场", "精致"]],
      ["棉服 + 卫衣 + 直筒裤", "轻松好活动，适合通勤和买东西。", ["通勤", "舒服"]],
      ["毛衣裙 + 厚打底 + 短靴", "省心又漂亮，室内脱外套也完整。", ["省心", "约会"]],
      ["派克服 + 工装裤", "抗风耐穿，适合天气不太友好的日子。", ["抗风", "耐穿"]],
      ["厚西装外套 + 高领衫 + 阔腿裤", "冷天也能保持利落感。", ["利落", "有型"]]
    ];
  }

  return base.map(([title, why, tags], index) => {
    const extras = [];
    if (rainy) extras.push("带伞，鞋子选不怕湿的一双");
    if (strongUv) extras.push("加防晒衫/帽子，浅色更友好");
    if (windy) extras.push("外套别太飘，包里放发圈");
    if (!extras.length) extras.push("按心情加一点亮色配饰");

    return {
      title,
      why: `${why}${extras[index % extras.length] ? ` ${extras[index % extras.length]}。` : ""}`,
      tags
    };
  });
}

function renderOutfits() {
  const context = getWeatherContext(state.weather);
  const options = stableShuffle(buildOutfitOptions(context), `outfit-${context.temp}-${context.uv}-${context.rain}`);
  const visible = rotateOptions(options, state.outfitOffset, 3);

  elements.outfitList.innerHTML = visible
    .map(
      (option) => `
        <article class="option-card">
          <strong>${option.title}</strong>
          <p>${option.why}</p>
          <div class="tag-row">
            ${option.tags.map((tag) => `<span class="tag">${tag}</span>`).join("")}
          </div>
        </article>
      `
    )
    .join("");
}

function isoDate(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function addDays(date, days) {
  const result = new Date(date);
  result.setDate(result.getDate() + days);
  return result;
}

function trackedCyclePhase(date = new Date()) {
  const tracker = state.settings.cycleTracker || {};
  if (!tracker.lastStart) return null;

  const lastStart = dateOnly(tracker.lastStart);
  if (Number.isNaN(lastStart.getTime())) return null;

  const cycleLength = clamp(Math.round(Number(tracker.cycleLength) || 28), 21, 45);
  const fallbackPeriodLength = clamp(Math.round(Number(tracker.periodLength) || 8), 3, 10);
  const lastEnd = tracker.lastEnd ? dateOnly(tracker.lastEnd) : null;
  const savedPeriodLength =
    lastEnd && !Number.isNaN(lastEnd.getTime())
      ? clamp(daysBetween(lastEnd, lastStart) + 1, 3, 10)
      : fallbackPeriodLength;
  const rawDays = daysBetween(date, lastStart);

  if (rawDays < 0) {
    const daysUntilStart = Math.abs(rawDays);
    return {
      key: daysUntilStart <= 3 ? "near" : "daily",
      label: `距记录开始约 ${daysUntilStart} 天`,
      note: daysUntilStart <= 3 ? "经期可能快到了，先少冰少酒，吃得暖一点。" : "周期记录在未来，先按日常轻盈照顾。",
      tracked: true,
      nextStart: tracker.lastStart
    };
  }

  const cycleIndex = Math.floor(rawDays / cycleLength);
  const dayInCycle = rawDays % cycleLength;
  const nextStart = addDays(lastStart, (cycleIndex + 1) * cycleLength);

  if (dayInCycle < savedPeriodLength) {
    return {
      key: "period",
      label: `经期第 ${dayInCycle + 1} 天左右`,
      note: "今天偏向温热、好消化、补一点铁和蛋白质；冰饮和重辣先让一让。",
      tracked: true,
      nextStart: isoDate(nextStart)
    };
  }

  if (dayInCycle <= savedPeriodLength + 7) {
    return {
      key: "recover",
      label: "恢复期",
      note: "适合把蛋白质、蔬菜和主食补回来，让身体慢慢恢复元气。",
      tracked: true,
      nextStart: isoDate(nextStart)
    };
  }

  const daysUntilNext = cycleLength - dayInCycle;
  if (daysUntilNext <= 3) {
    return {
      key: "near",
      label: `经期将近 · 约 ${daysUntilNext} 天`,
      note: "可以提前吃得稳一点，少冰少酒，晚餐别太咸，睡前轻松些。",
      tracked: true,
      nextStart: isoDate(nextStart)
    };
  }

  if (daysUntilNext <= 8) {
    return {
      key: "pms",
      label: "经前照顾",
      note: "这几天更适合稳定血糖和情绪，来点暖汤、粗粮和镁含量高的食物。",
      tracked: true,
      nextStart: isoDate(nextStart)
    };
  }

  return {
    key: "daily",
    label: "轻盈日常",
    note: "今天可以吃得清爽丰富，蛋白质、蔬菜和好吃的主食都安排上。",
    tracked: true,
    nextStart: isoDate(nextStart)
  };
}

function getCyclePhase(date = new Date()) {
  const tracked = trackedCyclePhase(date);
  if (tracked) return tracked;

  const start = clamp(Number(state.settings.periodStart) || 3, 1, 31);
  const end = clamp(Number(state.settings.periodEnd) || 10, 1, 31);
  const day = date.getDate();

  if (day >= start && day <= end) {
    return {
      key: "period",
      label: `经期第 ${day - start + 1} 天左右`,
      note: "今天偏向温热、好消化、补一点铁和蛋白质；冰饮和重辣先让一让。",
      tracked: false
    };
  }

  if (day >= Math.max(1, start - 2) && day < start) {
    return {
      key: "near",
      label: "经期将近",
      note: "可以提前吃得稳一点，少冰少酒，晚餐别太咸，睡前轻松些。",
      tracked: false
    };
  }

  if (day > end && day <= end + 7) {
    return {
      key: "recover",
      label: "恢复期",
      note: "适合把蛋白质、蔬菜和主食补回来，让身体慢慢恢复元气。",
      tracked: false
    };
  }

  if (day >= 24 || day < start) {
    return {
      key: "pms",
      label: "经前照顾",
      note: "这几天更适合稳定血糖和情绪，来点暖汤、粗粮和镁含量高的食物。",
      tracked: false
    };
  }

  return {
    key: "daily",
    label: "轻盈日常",
    note: "今天可以吃得清爽丰富，蛋白质、蔬菜和好吃的主食都安排上。",
    tracked: false
  };
}

function autoMealSlot(date = new Date()) {
  const hour = date.getHours();
  if (hour >= 5 && hour < 11) return "breakfast";
  if (hour >= 11 && hour < 16) return "lunch";
  return "dinner";
}

function activeMealSlot() {
  const preference = ["auto", "breakfast", "lunch", "dinner"].includes(state.settings.mealSlot)
    ? state.settings.mealSlot
    : "auto";
  return preference === "auto" ? autoMealSlot() : preference;
}

function mealSlotMeta(slot) {
  const labels = {
    breakfast: {
      label: "早餐",
      note: "早上优先热乎、好消化和稳定血糖，别让空腹把心情拖低。"
    },
    lunch: {
      label: "午餐",
      note: "中午吃得完整一点，主食、蛋白质和蔬菜都到位，下午会更稳。"
    },
    dinner: {
      label: "晚餐",
      note: "晚上偏向舒服和不负担，暖汤、蒸煮、少油一点会更友好。"
    }
  };
  return labels[slot] || labels.dinner;
}

function mealPool(phase, slot) {
  const common = {
    breakfast: [
      ["番茄鸡蛋酸汤面", "番茄酸口很醒胃，蒜末先炒熟出香，辣度只放一点点。", ["酸口", "微辣", "熟蒜"]],
      ["鸡蛋蔬菜三明治", "配番茄酸奶酱会更清爽，避开生蒜和厚重沙拉酱。", ["快手", "清爽"]],
      ["小米南瓜粥 + 醋溜小菜", "主食温和，小菜走酸口，早上吃不刺激。", ["温和", "酸口"]],
      ["豆浆 + 全麦吐司 + 番茄蛋", "能量稳定，番茄带一点酸，适合赶时间。", ["稳定", "早餐"]],
      ["熟蒜虾仁蒸蛋 + 小馒头", "蒜蓉蒸熟后只留香气，细腻好消化。", ["熟蒜", "蛋白质"]],
      ["酸辣馄饨", "汤底酸一点、辣一点点，早上吃热乎又醒胃。", ["酸辣", "热汤"]],
      ["番茄牛肉米线", "酸甜汤底配软米线，牛肉补能量。", ["米线", "酸口"]],
      ["酸菜肉丝面", "酸菜开胃，辣度轻一点，适合没胃口的早上。", ["酸菜", "微辣"]],
      ["鸡腿蛋堡 + 酸黄瓜", "想吃汉堡也可以，酱料选酸黄瓜口，别太油。", ["汉堡", "满足"]],
      ["培根芝士贝果", "咸香顶饱，配无糖酸奶会更清爽。", ["贝果", "饱腹"]],
      ["番茄鸡蛋手抓饼", "快手又满足，番茄酸甜能解腻。", ["快手", "酸甜"]],
      ["金枪鱼饭团 + 味噌汤", "轻一点但有蛋白质，适合忙早晨。", ["饭团", "轻盈"]],
      ["酸奶水果燕麦杯", "不想开火时选它，酸甜清爽。", ["酸甜", "免开火"]],
      ["熟蒜蘑菇蛋卷", "蘑菇和蒜片先炒香，再卷蛋，香但不冲。", ["熟蒜", "蛋白质"]]
    ],
    lunch: [
      ["蒜香番茄滑鸡饭", "鸡肉嫩一点，番茄酸甜开胃，蒜片炒熟后很下饭。", ["酸口", "熟蒜", "米饭"]],
      ["酸汤肥牛饭", "酸口明显但辣度控制在微辣，配米饭很满足。", ["酸汤", "微辣"]],
      ["醋溜西兰花牛肉", "补蛋白和铁，蒜末炝锅炒熟，醋香会更开胃。", ["补能量", "熟蒜"]],
      ["番茄咖喱鸡肉饭", "咖喱只要轻微辣，番茄让味道更明亮。", ["微辣", "下饭"]],
      ["酸辣虾仁芦笋意面", "酸辣清爽不重口，蒜香用熟蒜油带出来。", ["酸辣", "轻盈"]],
      ["酸辣粉", "想吃重口时可以安排，辣度选微辣，多加青菜和蛋更稳。", ["酸辣粉", "微辣"]],
      ["螺蛳粉", "酸笋和汤底都合口味，建议微辣，配青菜和煎蛋。", ["螺蛳粉", "酸辣"]],
      ["酸菜鱼米饭", "酸口足、蛋白质够，汤别喝太咸。", ["酸菜鱼", "下饭"]],
      ["牛肉芝士汉堡 + 玉米杯", "想吃汉堡就吃，配玉米杯比薯条更轻一点。", ["汉堡", "满足"]],
      ["酸黄瓜鸡腿堡", "酸黄瓜解腻，鸡腿堡满足感强。", ["汉堡", "酸口"]],
      ["番茄肉酱意面", "酸甜浓郁，午餐吃很有满足感。", ["意面", "酸甜"]],
      ["韩式拌饭", "酱料微辣，蔬菜多，搅开很香。", ["拌饭", "微辣"]],
      ["日式咖喱汉堡排饭", "肉感足，咖喱选微辣，配酸甜小菜。", ["汉堡排", "下饭"]],
      ["酸汤牛肉米线", "酸辣热汤加米线，适合想吃粉面的时候。", ["米线", "酸汤"]],
      ["熟蒜茄汁虾仁饭", "蒜香和番茄都在线，酸甜下饭。", ["熟蒜", "酸甜"]],
      ["番茄火锅冒菜", "菜品丰富，汤底酸口，辣度选微辣。", ["冒菜", "丰富"]],
      ["酸辣土豆粉", "口感软糯，酸辣开胃，适合偶尔换口味。", ["土豆粉", "酸辣"]],
      ["墨西哥鸡肉卷", "有酸奶酱和微辣鸡肉，拿着吃也方便。", ["卷饼", "微辣"]]
    ],
    dinner: [
      ["番茄青菜豆腐汤 + 米饭", "酸口暖汤，蒜末炒熟再煮汤，晚上吃轻松。", ["酸口", "暖汤"]],
      ["熟蒜蒸鲈鱼 + 青菜", "蒜蓉蒸熟后香而不冲，鱼肉清淡有蛋白质。", ["熟蒜", "高蛋白"]],
      ["酸汤丝瓜虾仁", "酸汤清爽，微辣即可，热一点的天也适合。", ["酸汤", "清爽"]],
      ["蒜香菌菇豆腐煲", "蒜片先煎香，热乎有鲜味，晚餐也不太负担。", ["熟蒜", "热乎"]],
      ["番茄土豆炖牛肉", "酸甜软糯有满足感，适合想被认真喂饱的晚上。", ["炖菜", "酸甜"]],
      ["轻量酸辣粉", "晚餐想吃粉也可以，少油少辣，多加青菜豆皮。", ["酸辣粉", "轻量"]],
      ["番茄酸汤馄饨", "酸汤热乎，晚上一碗很舒服。", ["酸汤", "馄饨"]],
      ["酸菜豆腐鱼片汤", "酸口开胃，鱼片轻，晚餐不太负担。", ["酸菜", "高蛋白"]],
      ["蒜香番茄鸡胸沙拉", "蒜香用熟蒜油，酸甜番茄汁解腻。", ["熟蒜", "轻食"]],
      ["照烧鸡腿堡 + 蔬菜汤", "想吃快餐时选这个组合，满足但不空。", ["汉堡", "蔬菜"]],
      ["酸辣藕片牛肉饭", "藕片脆、牛肉香，微辣下饭。", ["酸辣", "米饭"]],
      ["螺蛳粉小份 + 青菜", "馋螺蛳粉时点小份，辣度别太高。", ["螺蛳粉", "小份"]],
      ["番茄菌菇乌冬", "酸甜汤底，面条软滑，晚上很治愈。", ["乌冬", "酸甜"]],
      ["熟蒜蒸娃娃菜粉丝", "蒜蓉蒸熟后香，粉丝吸汁，轻但好吃。", ["熟蒜", "蒸菜"]],
      ["酸汤鸡蛋荞麦面", "酸口热汤，主食轻一点，睡前不撑。", ["酸汤", "轻盈"]],
      ["越南牛肉河粉", "清爽热汤，加一点青柠酸香，很适合晚餐。", ["河粉", "酸香"]]
    ]
  };

  const phaseBySlot = {
    period: {
      breakfast: [
        ["番茄瘦肉粥", "温热又有一点酸口，比白粥更有营养。", ["经期", "酸口"]],
        ["菠菜瘦肉粥 + 熟蒜青菜", "补铁温和，青菜用熟蒜提香，不碰生蒜。", ["补铁", "熟蒜"]],
        ["红枣小米粥 + 蒸蛋", "先把胃照顾舒服，酸辣口味放到午餐再满足。", ["温热", "好消化"]]
      ],
      lunch: [
        ["番茄牛腩饭", "酸甜开胃，牛肉炖软一点，经期也更好入口。", ["酸口", "补能量"]],
        ["微辣酸汤鸡片", "酸口满足，辣度轻一点，蒜只炒熟不生拌。", ["微辣", "熟蒜"]],
        ["菠菜猪肝瘦肉汤饭", "想补一点铁时很合适，口味清淡但可以加番茄提酸。", ["补铁", "热乎"]]
      ],
      dinner: [
        ["番茄山药排骨汤", "清润不油，番茄带酸，晚上吃一小碗刚好。", ["酸口", "暖汤"]],
        ["蒜香菌菇豆腐煲", "蒜片炒熟后再煲，热乎有鲜味。", ["熟蒜", "温热"]],
        ["鲫鱼豆腐汤 + 醋溜青菜", "暖汤收尾，青菜带一点酸更合口味。", ["暖汤", "酸口"]]
      ]
    },
    near: {
      breakfast: [
        ["番茄鸡蛋燕麦粥", "酸口轻轻打开胃口，早上也不会太刺激。", ["酸口", "稳定"]],
        ["黑芝麻豆浆 + 鸡蛋三明治", "先稳住能量，酱料选番茄酸奶口。", ["早餐", "稳定"]]
      ],
      lunch: [
        ["熟蒜清炒菠菜 + 蒸鱼 + 米饭", "不重口，蒜香是熟的，营养也够。", ["熟蒜", "蛋白质"]],
        ["酸汤菌菇鸡肉面", "暖汤面很安抚，酸口和微辣都可以轻一点。", ["酸汤", "好入口"]]
      ],
      dinner: [
        ["番茄莲藕排骨汤", "暖、酸甜、清，日常又不腻。", ["酸甜", "汤"]],
        ["番茄豆腐汤 + 小碗饭", "酸甜暖胃，晚上吃很轻松。", ["暖", "清爽"]]
      ]
    },
    recover: {
      breakfast: [
        ["酸奶燕麦 + 水煮蛋", "酸奶更合她口味，也能把蛋白质慢慢补回来。", ["恢复期", "酸口"]],
        ["番茄鸡蛋吐司", "适合轻早午餐，番茄酸甜，颜色也开心。", ["轻盈", "好看"]]
      ],
      lunch: [
        ["酸辣三色鸡丁盖饭", "蛋白质和蔬菜都有，微辣就好，别太冲。", ["微辣", "均衡"]],
        ["番茄豆腐牛肉汤饭", "酸甜、暖、蛋白质足。", ["酸甜", "补能量"]]
      ],
      dinner: [
        ["醋溜木耳炒鸡蛋 + 米饭", "快手又家常，酸口更开胃。", ["酸口", "家常"]],
        ["清蒸鱼 + 熟蒜青菜", "清淡但营养够，蒜蓉要蒸熟或炒熟。", ["清蒸", "熟蒜"]]
      ]
    },
    pms: {
      breakfast: [
        ["酸奶香蕉燕麦", "酸甜但更稳，适合想吃甜的时候。", ["酸甜", "早餐"]],
        ["紫薯豆浆 + 番茄鸡蛋", "饱腹感不错，番茄给一点酸口。", ["饱腹", "稳定"]]
      ],
      lunch: [
        ["柠檬香煎三文鱼 + 土豆泥", "酸香提味，油脂和蛋白质都友好。", ["酸香", "蛋白质"]],
        ["微辣番茄菠菜荞麦面", "主食不重，酸口微辣，下午也舒服。", ["微辣", "清爽"]]
      ],
      dinner: [
        ["酸汤紫菜虾皮馄饨", "热汤加主食，微酸微辣，吃完很安稳。", ["酸汤", "安抚"]],
        ["番茄黄豆猪蹄汤 + 青菜", "想吃胶质感时很满足，注意别太咸。", ["酸甜", "暖汤"]]
      ]
    },
    daily: {
      breakfast: [
        ["番茄牛油果鸡蛋吐司", "适合轻早餐，酸甜清爽，颜色也开心。", ["早餐", "酸口"]],
        ["酸奶水果燕麦碗", "清爽、快手，适合不想开火的早上。", ["酸甜", "快手"]]
      ],
      lunch: [
        ["酸辣照烧鸡腿饭", "家常但有满足感，微辣解腻，配生菜很稳。", ["微辣", "满足"]],
        ["熟蒜肉末茄子盖饭", "蒜末炒熟后香，下饭但别做太油。", ["熟蒜", "下饭"]]
      ],
      dinner: [
        ["熟蒜虾仁蒸蛋 + 醋溜青菜", "细腻好消化，也能照顾酸口和蒜香。", ["熟蒜", "酸口"]],
        ["番茄鸡蛋酸汤面", "热乎、快手，适合不知道吃什么的时候。", ["酸汤", "家常"]]
      ]
    }
  };

  return [...(phaseBySlot[phase.key]?.[slot] || []), ...common[slot]];
}

function renderMealSlotControls(slot) {
  const preference = ["auto", "breakfast", "lunch", "dinner"].includes(state.settings.mealSlot)
    ? state.settings.mealSlot
    : "auto";

  document.querySelectorAll("[data-meal-slot]").forEach((button) => {
    const selected = button.dataset.mealSlot === preference;
    button.classList.toggle("is-selected", selected);
    button.setAttribute("aria-pressed", String(selected));
  });

  const meta = mealSlotMeta(slot);
  elements.mealSlotLabel.textContent =
    preference === "auto" ? `自动按当前时间 · ${meta.label}` : `手动选择 · ${meta.label}`;
}

function formatShortDate(value) {
  if (!value) return "--";
  const date = dateOnly(value);
  if (Number.isNaN(date.getTime())) return "--";
  return new Intl.DateTimeFormat("zh-CN", {
    month: "numeric",
    day: "numeric"
  }).format(date);
}

function renderCycleTracker(phase) {
  const tracker = state.settings.cycleTracker || {};
  const cycleLength = clamp(Math.round(Number(tracker.cycleLength) || 28), 21, 45);

  elements.cyclePhase.textContent = phase.tracked
    ? `${phase.label} · 追踪中`
    : `${phase.label} · 默认 3-10 号`;
  elements.cycleTrackerSummary.textContent = phase.tracked
    ? `已记录 ${formatShortDate(tracker.lastStart)} 开始，预计下次约 ${formatShortDate(phase.nextStart)}；周期按 ${cycleLength} 天估算。`
    : "未记录周期时，先按每月 3-10 号估算；记录后会自动预测下一次。";
  elements.lastPeriodStartInput.value = tracker.lastStart || "";
  elements.lastPeriodEndInput.value = tracker.lastEnd || "";
  elements.cycleLengthInput.value = cycleLength;
}

function renderMeals() {
  const phase = getCyclePhase();
  const slot = activeMealSlot();
  const slotMeta = mealSlotMeta(slot);
  const options = stableShuffle(mealPool(phase, slot), `meal-${phase.key}-${slot}`);
  const visible = rotateOptions(options, state.mealOffset, 4);
  const tasteNote = "口味默认偏酸、微辣，蒜只做熟蒜香，不放生蒜。";

  renderCycleTracker(phase);
  elements.mealNote.textContent = `${slotMeta.note} ${phase.note} ${tasteNote}`;
  renderMealSlotControls(slot);
  elements.mealList.innerHTML = visible
    .map(
      ([title, why, tags]) => `
        <article class="option-card">
          <strong>${title}</strong>
          <p>${why}</p>
          <div class="tag-row">
            ${tags.map((tag) => `<span class="tag">${tag}</span>`).join("")}
          </div>
        </article>
      `
    )
    .join("");
}

function dateOnly(value) {
  const [year, month, day] = value.split("-").map(Number);
  return new Date(year, month - 1, day);
}

function daysBetween(a, b) {
  const oneDay = 24 * 60 * 60 * 1000;
  const start = new Date(a.getFullYear(), a.getMonth(), a.getDate()).getTime();
  const end = new Date(b.getFullYear(), b.getMonth(), b.getDate()).getTime();
  return Math.round((start - end) / oneDay);
}

function inRange(date, start, end) {
  return daysBetween(date, start) >= 0 && daysBetween(end, date) >= 0;
}

function retrogradeStatus(date = new Date()) {
  const random = seededRandom(hashString(`${dateKey(date)}-mercury`));
  const cycle = mercuryCycles2026.find((item) => {
    return inRange(date, dateOnly(item.shadowStart), dateOnly(item.shadowEnd));
  });

  if (!cycle) {
    const score = Math.round(12 + random() * 18);
    return {
      score,
      label: "顺行日",
      note: "水逆感偏低，重要消息照常检查一遍就很好。"
    };
  }

  const start = dateOnly(cycle.start);
  const end = dateOnly(cycle.end);
  const shadowStart = dateOnly(cycle.shadowStart);
  const shadowEnd = dateOnly(cycle.shadowEnd);

  if (inRange(date, start, end)) {
    const distanceToStation = Math.min(Math.abs(daysBetween(date, start)), Math.abs(daysBetween(end, date)));
    const score = clamp(Math.round(80 + (8 - Math.min(distanceToStation, 8)) * 1.8 + random() * 6), 78, 96);
    return {
      score,
      label: cycle.label,
      note: "水逆进行中，消息、时间和行程多确认一次；慢一点反而更稳。"
    };
  }

  const before = daysBetween(start, date) > 0;
  const distance = before ? Math.abs(daysBetween(date, shadowStart)) : Math.abs(daysBetween(shadowEnd, date));
  const score = clamp(Math.round(42 + (14 - Math.min(distance, 14)) * 1.2 + random() * 5), 38, 62);

  return {
    score,
    label: before ? "水逆前影期" : "水逆后影期",
    note: before ? "前影期适合备份、整理和提前沟通。" : "后影期适合复盘、修正和把节奏慢慢找回来。"
  };
}

function renderLuck() {
  const color = stablePick(luckyColors, "color");
  const item = stablePick(luckyItems, "item");
  const note = stablePick(luckyNotes, "note");
  const retrograde = retrogradeStatus();

  elements.luckyColor.textContent = color;
  elements.luckyItem.textContent = item;
  elements.luckyNote.textContent = note;
  elements.retrogradeScore.textContent = `${retrograde.score}%`;
  elements.retrogradeMeter.style.width = `${retrograde.score}%`;
  elements.retrogradeNote.textContent = `${retrograde.label} · ${retrograde.note}`;
}

async function updateFromLocation(location) {
  setLoading(true);
  try {
    state.location = location;
    elements.locationName.textContent = location.name;
    state.weather = await fetchWeather(location);
    saveSettings();
    renderWeather();
    showToast("今天的天气已更新");
  } catch (error) {
    showToast(readableFetchError(error, "天气更新失败"));
    renderWeather();
  } finally {
    setLoading(false);
  }
}

async function useCurrentLocation() {
  setLoading(true);
  try {
    const position = await getPosition();
    const { latitude, longitude } = position.coords;
    const name = await reverseGeocode(latitude, longitude);
    await updateFromLocation({ name, latitude, longitude });
  } catch (error) {
    setLoading(false);
    showToast(readableFetchError(error, "定位失败，可以输入城市试试"));
  }
}

async function useCitySearch() {
  const name = elements.cityInput.value.trim();
  if (!name) {
    showToast("先输入一个城市名");
    return;
  }

  setLoading(true);
  try {
    const location = await searchCity(name);
    await updateFromLocation(location);
    elements.cityInput.value = "";
  } catch (error) {
    showToast(readableFetchError(error, "城市搜索失败"));
  } finally {
    setLoading(false);
  }
}

function readableFetchError(error, fallback) {
  const message = error?.message || "";

  if (/failed to fetch|networkerror/i.test(message)) {
    return "网络请求失败，天气接口可能被当前浏览器拦截；可以试试系统浏览器或直接输入城市。";
  }

  if (/permission|denied|secure|origin/i.test(message)) {
    return "定位权限没拿到；本地预览请用 127.0.0.1，正式发给她时需要 HTTPS。";
  }

  return message || fallback;
}

function saveCycle() {
  const lastStart = elements.lastPeriodStartInput.value;
  const lastEnd = elements.lastPeriodEndInput.value;
  const cycleLength = clamp(Math.round(Number(elements.cycleLengthInput.value) || 28), 21, 45);

  if (lastEnd && !lastStart) {
    showToast("先填上次开始日期，再填结束日期");
    return;
  }

  if (lastStart && lastEnd && daysBetween(dateOnly(lastEnd), dateOnly(lastStart)) < 0) {
    showToast("结束日期需要晚于开始日期");
    return;
  }

  state.settings.cycleTracker = {
    ...state.settings.cycleTracker,
    lastStart,
    lastEnd,
    cycleLength
  };

  if (lastStart && lastEnd) {
    state.settings.cycleTracker.periodLength = clamp(daysBetween(dateOnly(lastEnd), dateOnly(lastStart)) + 1, 3, 10);
  }

  state.mealOffset = 0;
  saveSettings();
  renderMeals();
  showToast(lastStart ? "周期追踪已保存" : "已清空周期记录，暂按 3-10 号估算");
}

function markPeriodStart() {
  state.settings.cycleTracker = {
    ...state.settings.cycleTracker,
    lastStart: isoDate(),
    lastEnd: ""
  };
  state.mealOffset = 0;
  saveSettings();
  renderMeals();
  showToast("已记录今天开始");
}

function markPeriodEnd() {
  const today = isoDate();
  const tracker = state.settings.cycleTracker || {};
  const lastStart = tracker.lastStart && daysBetween(dateOnly(today), dateOnly(tracker.lastStart)) >= 0 ? tracker.lastStart : today;

  state.settings.cycleTracker = {
    ...tracker,
    lastStart,
    lastEnd: today,
    periodLength: clamp(daysBetween(dateOnly(today), dateOnly(lastStart)) + 1, 3, 10)
  };
  state.mealOffset = 0;
  saveSettings();
  renderMeals();
  showToast(tracker.lastStart ? "已记录今天结束" : "已记录今天结束，可再补上开始日期");
}

function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) return;
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => {
      // App still works without a service worker.
    });
  });
}

function setupInstallPrompt() {
  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    state.deferredInstallPrompt = event;
    elements.installButton.hidden = false;
  });

  elements.installButton.addEventListener("click", async () => {
    if (!state.deferredInstallPrompt) return;
    state.deferredInstallPrompt.prompt();
    await state.deferredInstallPrompt.userChoice;
    state.deferredInstallPrompt = null;
    elements.installButton.hidden = true;
  });
}

function cacheElements() {
  [
    "dateLine",
    "greetingLine",
    "useLocationButton",
    "installButton",
    "locationName",
    "cityInput",
    "citySearchButton",
    "currentTemp",
    "weatherSummary",
    "uvValue",
    "uvMeter",
    "uvLabel",
    "feelsLike",
    "comfortNote",
    "spfBadge",
    "sunscreenAdvice",
    "shuffleOutfitsButton",
    "outfitList",
    "luckyColor",
    "luckyItem",
    "luckyNote",
    "retrogradeScore",
    "retrogradeMeter",
    "retrogradeNote",
    "cyclePhase",
    "shuffleMealsButton",
    "cycleTrackerSummary",
    "markPeriodStartButton",
    "markPeriodEndButton",
    "lastPeriodStartInput",
    "lastPeriodEndInput",
    "cycleLengthInput",
    "saveCycleButton",
    "mealSlotLabel",
    "mealNote",
    "mealList",
    "toast"
  ].forEach((id) => {
    elements[id] = document.getElementById(id);
  });
}

function bindEvents() {
  elements.useLocationButton.addEventListener("click", useCurrentLocation);
  elements.citySearchButton.addEventListener("click", useCitySearch);
  elements.cityInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") useCitySearch();
  });
  elements.shuffleOutfitsButton.addEventListener("click", () => {
    state.outfitOffset += 3;
    renderOutfits();
  });
  elements.shuffleMealsButton.addEventListener("click", () => {
    state.mealOffset += 4;
    renderMeals();
  });
  document.querySelectorAll("[data-meal-slot]").forEach((button) => {
    button.addEventListener("click", () => {
      state.settings.mealSlot = button.dataset.mealSlot;
      state.mealOffset = 0;
      saveSettings();
      renderMeals();
    });
  });
  elements.markPeriodStartButton.addEventListener("click", markPeriodStart);
  elements.markPeriodEndButton.addEventListener("click", markPeriodEnd);
  elements.saveCycleButton.addEventListener("click", saveCycle);
}

async function hydrateSavedLocation() {
  if (!state.location) {
    renderWeather();
    return;
  }

  elements.locationName.textContent = state.location.name;
  try {
    state.weather = await fetchWeather(state.location);
  } catch {
    showToast("天气暂时没更新，先看离线建议");
  }
  renderWeather();
}

function init() {
  cacheElements();
  loadSettings();
  bindEvents();
  setupInstallPrompt();
  registerServiceWorker();

  elements.dateLine.textContent = formatDate(new Date());
  elements.greetingLine.textContent = `${stablePick(["今天也要被好好照顾。", "把舒服、漂亮和好运都安排上。", "出门前看一眼，心里会更有底。"], "greeting")}`;

  renderLuck();
  renderMeals();
  hydrateSavedLocation();

  if (window.lucide) {
    window.lucide.createIcons();
  } else {
    window.addEventListener("load", () => window.lucide?.createIcons());
  }
}

init();
