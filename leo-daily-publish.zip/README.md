# 今日小狮子

一个静态 PWA 小应用：定位她所在城市，调用 Open-Meteo 获取天气和紫外线，给出防晒、穿搭、幸运物、水逆程度和饮食建议。

## 本地预览

在 `outputs/leo-daily` 目录启动任意静态服务器即可，例如：

```powershell
python -m http.server 4173
```

然后打开 `http://localhost:4173/`。

## 给她安装

这个版本建议部署成 HTTPS 网页，避免你们不在同一网络时无法访问。最省事的方式：

1. 把整个 `outputs/leo-daily` 文件夹上传到 Netlify、Vercel、Cloudflare Pages 或 GitHub Pages。
2. 得到 HTTPS 链接后，把 `/install.html` 这个安装页发给她。
3. 页面会根据她的手机提示下一步：Android 用 Chrome 安装，iPhone 用 Safari 添加到主屏幕。
4. 如果她从微信或 QQ 打开，先按页面提示切到系统浏览器。

定位和 PWA 安装都需要 HTTPS；如果只是微信/QQ 里打开，遇到定位或安装受限时，让她复制链接到系统浏览器。

## 可调整项

- 生理周期可在应用里追踪：记录上次开始/结束和周期长度，或直接点“今天开始”“今天结束”；数据只保存在她自己的浏览器里。
- 饮食推荐默认按当前时间切到早餐、午餐或晚餐，也可以手动选择餐次。
- 饮食口味默认偏酸、微辣，蒜只做熟蒜香，不推荐生蒜；候选包含家常饭菜、粉面、米线、螺蛳粉、酸辣粉、汉堡、轻食等。
- 水逆程度是娱乐向，内置 2026 年水逆和影期表。
- 没有后端服务器，城市、经期范围等只保存在她自己的浏览器里。

## 数据来源

- 天气与紫外线：[Open-Meteo Forecast API](https://open-meteo.com/en/docs)。
- 城市搜索：[Open-Meteo Geocoding API](https://open-meteo.com/en/docs/geocoding-api)。
- 定位后的城市名反查：[BigDataCloud Reverse Geocoding to City API](https://www.bigdatacloud.com/free-api/free-reverse-geocode-to-city-api)；反查失败时仍会用坐标继续查天气。
- 2026 水逆日期：[Britannica](https://www.britannica.com/question/When-is-Mercury-in-retrograde-in-2026) 与 [Astro Engine](https://astro-engine.com/mercury-retrograde) 的 2026 Mercury retrograde 日期。
